<br><br><br><br><br><br>
<?php $this->load->view('components/location'); ?>
<?php $this->load->view('components/contact'); ?>
