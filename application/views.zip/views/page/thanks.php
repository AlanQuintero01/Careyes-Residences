<div class="thanksImage">
  <div class="thanksText">
    <h2 class="text-white letter textShadow">GRACIAS POR REGÍSTRARTE</h2>
  </div>
</div>
